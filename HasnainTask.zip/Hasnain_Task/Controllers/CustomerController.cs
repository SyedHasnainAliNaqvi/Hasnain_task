﻿using Hasnain_Task.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Hasnain_Task.Controllers
{
    public class CustomerController : Controller
    {
        // GET: Customer

        HasnainTaskEntities dbObj = new HasnainTaskEntities();
        public ActionResult Customer()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddCustomer(tbl_Customer model)
        {

            if (ModelState.IsValid)
            {
                tbl_Customer obj = new tbl_Customer();
                obj.CustomerName = model.CustomerName;
                obj.CustomerEmail = model.CustomerEmail;
                obj.CustomerPhoneNumber = model.CustomerPhoneNumber;


                dbObj.tbl_Customer.Add(obj);
                dbObj.SaveChanges();

            }
            ModelState.Clear();
            return View("Customer");
        }

       
    }


  
}
