

namespace Hasnain_Task.Context
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public partial class tbl_Customer
    {
        public int ID { get; set; }
        [Required(ErrorMessage = "Required")]
        public string CustomerName { get; set; }
        [Required(ErrorMessage = "Required")]
        public string CustomerEmail { get; set; }
        [Required(ErrorMessage = "Required")]
        [MinLength(11,ErrorMessage = "Mobile Number Should Be 11 digits")]
        public string CustomerPhoneNumber { get; set; }
    }
}
